<?php
/**
 * The "Not carried over" section shared by both report screens: things the
 * conversion could not express at all, each with the node it belonged to.
 */

namespace BeaverDivi5Converter\Admin;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NotCarriedOverRenderer {

    /**
     * @param array $entries     From the report's `not_carried_over` key.
     * @param array $approximate From the report's `approximate_matches` key.
     * @param array $unresolved  From the report's `unresolved_globals` key.
     */
    public static function render( array $entries, array $approximate = [], array $unresolved = [], array $addon_defaults = [] ): string {
        if ( empty( $entries ) && empty( $approximate ) && empty( $unresolved ) ) {
            return self::addonDefaults( $addon_defaults );
        }

        $html = '<div class="bdc-not-carried"><h3>' . esc_html__( 'Not carried over', 'jhmg-converter-for-beaver-builder-to-divi-5' ) . '</h3>';

        foreach ( self::groups() as $kind => $label ) {
            $rows = array_values( array_filter( $entries, static fn( array $e ): bool => ( $e['kind'] ?? '' ) === $kind ) );
            if ( empty( $rows ) ) {
                continue;
            }
            $html .= '<p class="bdc-not-carried-label"><strong>' . esc_html( $label ) . '</strong></p><ul class="bdc-not-carried-list">';
            foreach ( $rows as $row ) {
                $html .= '<li><code>' . esc_html( (string) ( $row['node_id'] ?? '' ) ) . '</code> — ' . esc_html( (string) ( $row['detail'] ?? '' ) ) . '</li>';
            }
            $html .= '</ul>';
        }

        if ( ! empty( $unresolved ) ) {
            $html .= '<p class="bdc-not-carried-label"><strong>' . esc_html__( 'Global colours that could not be resolved — the setting was left empty rather than guessed', 'jhmg-converter-for-beaver-builder-to-divi-5' ) . '</strong></p><ul class="bdc-not-carried-list">';
            foreach ( $unresolved as $row ) {
                $html .= '<li><code>' . esc_html( (string) ( $row['node_id'] ?? '' ) ) . '</code> — ' . esc_html( (string) ( $row['setting_key'] ?? '' ) ) . ' = ' . esc_html( (string) ( $row['ref'] ?? '' ) ) . '</li>';
            }
            $html .= '</ul>';
        }

        if ( ! empty( $approximate ) ) {
            $html .= '<p class="bdc-not-carried-label"><strong>' . esc_html__( 'Approximate conversions — Beaver Builder Pro modules mapped from documentation rather than source; check them', 'jhmg-converter-for-beaver-builder-to-divi-5' ) . '</strong></p><ul class="bdc-not-carried-list">';
            foreach ( $approximate as $row ) {
                $html .= '<li><code>' . esc_html( (string) ( $row['node_id'] ?? '' ) ) . '</code> — ' . esc_html( (string) ( $row['module'] ?? '' ) ) . ' → ' . esc_html( (string) ( $row['matched_to'] ?? '' ) ) . '</li>';
            }
            $html .= '</ul>';
        }

        return $html . '</div>' . self::addonDefaults( $addon_defaults );
    }

    /**
     * Add-on settings (Ultimate Addons, PowerPack) that every row and column of
     * such a site carries at their defaults. Nothing was lost; the count shows
     * why the page held so many settings the converter did not need to map.
     *
     * @param array<string, int> $addon_defaults From the report's `addon_settings_ignored` key.
     */
    public static function addonDefaults( array $addon_defaults ): string {
        if ( empty( $addon_defaults ) ) {
            return '';
        }
        $parts = [];
        foreach ( $addon_defaults as $label => $count ) {
            $parts[] = sprintf(
                /* translators: 1: add-on feature, 2: number of rows/columns */
                _n( '%1$s (%2$d node)', '%1$s (%2$d nodes)', (int) $count, 'jhmg-converter-for-beaver-builder-to-divi-5' ),
                (string) $label,
                (int) $count
            );
        }
        return '<p class="bdc-addon-defaults"><strong>' . esc_html__( 'Add-on settings left at their defaults were ignored:', 'jhmg-converter-for-beaver-builder-to-divi-5' ) . '</strong> ' . esc_html( implode( '; ', $parts ) ) . '</p>';
    }

    private static function groups(): array {
        return [
            'animation'   => __( 'Animations — removed', 'jhmg-converter-for-beaver-builder-to-divi-5' ),
            'visibility'  => __( 'Logged-in / logged-out visibility rules — removed; the element shows to everyone', 'jhmg-converter-for-beaver-builder-to-divi-5' ),
            'shapes'      => __( 'Row shape layers — removed', 'jhmg-converter-for-beaver-builder-to-divi-5' ),
            'background'  => __( 'Backgrounds that could only be approximated', 'jhmg-converter-for-beaver-builder-to-divi-5' ),
            'lightbox'    => __( 'Lightbox behaviour — the link or video opens normally instead', 'jhmg-converter-for-beaver-builder-to-divi-5' ),
            'hover'       => __( 'Hover colours — the resting colours are kept', 'jhmg-converter-for-beaver-builder-to-divi-5' ),
            'interaction' => __( 'Click actions and interactive behaviour — needs rebuilding in Divi', 'jhmg-converter-for-beaver-builder-to-divi-5' ),
            'integration' => __( 'Third-party connections — reconnect in the Divi module', 'jhmg-converter-for-beaver-builder-to-divi-5' ),
            'custom_code' => __( 'Layout-level custom CSS and JavaScript — copy it into Divi → Theme Options if still needed', 'jhmg-converter-for-beaver-builder-to-divi-5' ),
            'unfiltered_html' => __( 'HTML reduced to what your account may publish (WordPress unfiltered_html capability) — scripts, iframes and event handlers were removed; an administrator can add them back in the Divi Code module', 'jhmg-converter-for-beaver-builder-to-divi-5' ),
        ];
    }
}
